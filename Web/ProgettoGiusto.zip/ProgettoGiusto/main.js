

function appartamento(){
    document.getElementById("nascondi2").style.display = "none";
    document.getElementById("nascondi").style.display = "block";
}

function cancel(){
    document.getElementById("nascondi2").style.display = "block";

}
